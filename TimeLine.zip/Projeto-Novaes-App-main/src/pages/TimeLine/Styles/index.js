import { StyleSheet } from "react-native";

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center'
    },
    btnEtapa:{
        height: 80,
        width: 80,
        backgroundColor: '#007B8F',
        borderRadius: 40,
        alignItems: 'center',
        justifyContent: 'center'
    },
    btnAdd: {
        height: 60,
        width: 60,
        backgroundColor: '#007B8F',
        borderRadius: 40,
        alignItems: 'center',
        justifyContent: 'center'
    },
    btnEdit: {
        height: 60,
        width: 60,
        backgroundColor: '#00A148',
        borderRadius: 40,
        alignItems: 'center',
        justifyContent: 'center'
    },
    btnDelete: {
        height: 60,
        width: 60,
        backgroundColor: '#E56D01',
        borderRadius: 40,
        alignItems: 'center',
        justifyContent: 'center'
    },
    mainEtapa: {
        flexDirection: "row",
        marginVertical: 10
    },
    boxEtapa:{
        borderColor: '#007B8F',
        borderWidth: 1,
        marginLeft: 5,
        borderRadius: 10,
        alignItems: 'center',
        maxWidth: 300,
        width: 300,
        paddingVertical: 10
    },
    modalContainer:{
        width: 300, // Ajuste o tamanho conforme necessário
        height: 300, // Ajuste o tamanho conforme necessário
        backgroundColor: '#007B8F',
        borderRadius: 10,
        alignItems: 'center',
        alignSelf: 'center',
        marginTop: 'auto',
        marginBottom: 'auto',
        elevation: 10,
    },
    modalContent:{
        marginTop: 30,
        height: 150,
        alignItems: 'center',
        width: '80%'
    },
    titulo:{
        fontSize: 23,
        color: 'white',
        textDecorationLine: 'underline'
    },
    txt:{
        fontSize: 18,
        color: '#007B8F'
    },
    inputTitulo: { 
        alignSelf: 'center',
        height: 35,
        width: '100%',
        backgroundColor: 'white',
        borderRadius: 5,
        textAlign: 'left',
        marginBottom: 10,
        padding: 5
    },
    inputDescricao:{
        height: 100,
        width: '100%',
        backgroundColor: 'white',
        borderRadius: 5,
        textAlign: 'left',
        paddingBottom: 78,
        padding: 5
    },
    btnSalvar:{
        height: 40,
        width: 150,
        borderRadius: 5,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'white',
        marginTop: 10
    },
    settings:{
        flexDirection: 'row'
    },
})

export default styles;