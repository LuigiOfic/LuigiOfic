import React, { useState } from "react";
import {
  View,
  TouchableOpacity,
  Text,
  TextInput,
  Modal,
  FlatList,
  ScrollView,
} from "react-native";
import { useNavigation } from "@react-navigation/native";
import styles from "./Styles";
import Icon_Plus from "react-native-vector-icons/Entypo";
import Icon_Clock from "react-native-vector-icons/Feather";
import Icon_Edit from "react-native-vector-icons/FontAwesome";
import Icon_Trash from "react-native-vector-icons/Entypo";
import Icon_ArrowLeft from "react-native-vector-icons/AntDesign";

export default function TimeLineScreen() {
  const navigation = useNavigation();
  const [modalVisible, setModalVisible] = useState(false);
  const [titulo, setTitulo] = useState("");
  const [descricao, setDescricao] = useState("");
  const [dataHora, setDataHora] = useState("");
  const [etapas, setEtapas] = useState([]);
  const [etapaSelecionada, setEtapaSelecionada] = useState(null);

  const adicionarEtapa = () => {
    // Adiciona a nova etapa ao estado
    if (etapaSelecionada !== null) {
      // Editar a etapa existente
      const etapasAtualizadas = etapas.map((etapa, index) => {
        if (index === etapaSelecionada) {
          return { titulo, descricao, dataHora };
        }
        return etapa;
      });

      setEtapas(etapasAtualizadas);
      setEtapaSelecionada(null);
    } else {
      // Adicionar nova etapa
      setEtapas([...etapas, { titulo, descricao, dataHora }]);
    }

    // Limpar os campos após adicionar/editar a etapa
    setTitulo("");
    setDescricao("");
    setDataHora("");

    // Fecha a modal
    setModalVisible(false);
  };

  const editarEtapa = (index) => {
    // Configura os detalhes da etapa selecionada para a edição
    const etapa = etapas[index];
    setEtapaSelecionada(index);
    setTitulo(etapa.titulo);
    setDescricao(etapa.descricao);
    setDataHora(etapa.dataHora);

    // Abre a modal
    setModalVisible(true);
  };

  

  return (
    <ScrollView>
      <View style={styles.container}>
        <View style={styles.main}>
          {/* Botão "Adicionar Etapa" */}
          {/* Lista de Etapas */}
          <FlatList
            data={etapas}
            keyExtractor={(item, index) => index.toString()}
            renderItem={({ item, index }) => (
              <View style={styles.mainEtapa}>
                <TouchableOpacity
                  style={styles.btnEtapa}
                  onPress={() => editarEtapa(index)}
                >
                  <Icon_Clock
                    name="clock"
                    size={60}
                    color={"#FFF"}
                  ></Icon_Clock>
                </TouchableOpacity>
                <View style={styles.boxEtapa}>
                  <Text>{`Título: ${item.titulo}`}</Text>
                  <Text>
                    --------------------------------------------------------------
                  </Text>
                  <Text>{`Descrição: ${item.descricao}`}</Text>
                </View>
              </View>
            )}
          />

          <View style={styles.settings}>
            <TouchableOpacity
              id="adicionar"
              style={styles.btnAdd}
              onPress={() => {
                setEtapaSelecionada(null);
                setModalVisible(true);
              }}
            >
              <Icon_Plus name="plus" size={55} color={"#FFF"}></Icon_Plus>
            </TouchableOpacity>
            <TouchableOpacity
              id="editar"
              style={styles.btnEdit}
              onPress={() => {
                if (etapaSelecionada !== null) {
                  // Implemente a lógica específica para o botão de edição
                  // Neste exemplo, apenas exibindo um alerta
                  alert("Botão de editar clicado");
                }
              }}
            >
              <Icon_Edit name="pencil" size={35} color={"#FFF"}></Icon_Edit>
            </TouchableOpacity>
            <TouchableOpacity
              id="excluir"
              style={styles.btnDelete}
            
            >
              <Icon_Trash name="trash" size={35} color={"#FFF"}></Icon_Trash>
            </TouchableOpacity>
          </View>
          <Icon_ArrowLeft
            name="arrowleft"
            size={50}
            color={"#FFF"}
          ></Icon_ArrowLeft>

          {/* Modal para adicionar/editar Etapa */}
          <Modal
            style={styles.Modal}
            animationType="fade"
            transparent={true}
            visible={modalVisible}
            onRequestClose={() => {
              setEtapaSelecionada(null);
              setModalVisible(false);
            }}
          >
            <View style={styles.modalContainer}>
              <Text style={styles.titulo}>
                {etapaSelecionada !== null
                  ? "Editar Etapa"
                  : "Adicionar Nova Etapa"}
              </Text>
              <View style={styles.modalContent}>
                <TextInput
                  style={styles.inputTitulo}
                  value={titulo}
                  onChangeText={(text) => setTitulo(text)}
                  placeholder="Título"
                  placeholderTextColor="grey"
                  maxLength={40}
                />
                <TextInput
                  style={styles.inputDescricao}
                  value={descricao}
                  onChangeText={(text) => setDescricao(text)}
                  placeholder="Descrição"
                  placeholderTextColor="grey"
                  maxLength={71}
                />
              </View>
              <TouchableOpacity
                style={styles.btnSalvar}
                title="Adicionar"
                onPress={adicionarEtapa}
              >
                <Text style={styles.txt}>
                  {etapaSelecionada !== null ? "Salvar" : "Adicionar"}
                </Text>
              </TouchableOpacity>
            </View>
          </Modal>
        </View>
      </View>
    </ScrollView>
  );
}
