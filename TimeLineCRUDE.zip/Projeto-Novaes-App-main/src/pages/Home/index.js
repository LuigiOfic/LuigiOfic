import React from "react";
import { View, Text, Button, Image , TouchableOpacity } from "react-native";
import { useNavigation } from "@react-navigation/native";
import styles from "./Styles";

export default function Home() {
  const navigation = useNavigation();

  return (
    <View style={styles.container}>
          <Image
          style={styles.image}
            source={require("../../img/LogoGrupoNovaesGrande.png")}
          />

          <View style={styles.btnContainer}>
              <TouchableOpacity style={styles.containerButton} onPress={() =>{navigation.navigate('Login')}}>
                  <Text style={styles.buttonEntrar}>Entrar</Text>
              </TouchableOpacity>

              <TouchableOpacity style={styles.containerButton} onPress={() =>{navigation.navigate('Register')}}>
                  <Text style={styles.buttonCadastrar}>Cadastrar</Text>
              </TouchableOpacity>
          </View>
    </View>
  );

}
