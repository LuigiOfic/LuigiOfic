
const colors ={
    primary: '#007B8F',
    secondary: '',
    branco: '#FFF',
    cinza: '#222',
    cinzaClaro: '#A1A1A1'
}

export default colors;