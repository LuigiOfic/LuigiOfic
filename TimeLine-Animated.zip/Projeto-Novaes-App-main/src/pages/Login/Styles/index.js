import { StyleSheet } from "react-native";

const styles = StyleSheet.create({
  container: {
    height: "100%",
    width: "100%",
    alignItems: "center",
    justifyContent: 'center'
  },
  header: {
    alignItems: "center",
    justifyContent: 'center',
    width: "100%",
  },
  linear: {
    alignItems: "center",
    width: "100%",
    justifyContent: 'center',
    borderRadius: 20,
    paddingBottom: 5,
  },
  main: {
    justifyContent: "center",
    width: "90%",
    flexDirection: "column",
    borderRadius: 20,
    alignItems: 'center',
    marginTop: 50,
    paddingBottom: 5,
    shadowColor: 'black',
    shadowOpacity: 0.9,
    shadowRadius: 3,
  },
  texto_login: {
    color: "#007B8F",
    fontSize: 21,
    marginVertical: 8,
  },
  input_login: {
    backgroundColor: 'white',
    padding: 10,
    borderRadius: 10,
    marginVertical: 6,
    width: 290,
    fontSize: 15
  },
  btn_login: {
    backgroundColor: "#007B8F",
    padding: 10,
    borderRadius: 10,
    width: 130,
    alignItems: 'center',
    justifyContent: 'center',
    textAlign: 'center',
    marginVertical: 15,
    marginBottom: 35
  },
  text_entrar: {
    color: 'white',
    fontSize: 16
  },
  text_descricao: {
    fontSize: 14,
    marginVertical: 2,
    textDecorationLine: 'underline',
  },
});

export default styles;
