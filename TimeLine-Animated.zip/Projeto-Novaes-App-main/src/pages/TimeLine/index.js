import React, { useState, useRef } from "react";
import {
  View,
  TouchableOpacity,
  Text,
  TextInput,
  Modal,
  FlatList,
  ScrollView,
  Animated,
} from "react-native";
import { useNavigation } from "@react-navigation/native";
import styles from "./Styles";
import Icon_Plus from "react-native-vector-icons/Entypo";
import Icon_Clock from "react-native-vector-icons/Feather";
import Icon_Edit from "react-native-vector-icons/FontAwesome";
import Icon_Trash from "react-native-vector-icons/Entypo";
import Icon_ArrowLeft from "react-native-vector-icons/AntDesign";

export default function TimeLineScreen() {
  const navigation = useNavigation();
  const [modalVisible, setModalVisible] = useState(false);
  const [titulo, setTitulo] = useState("");
  const [descricao, setDescricao] = useState("");
  const [dataHora, setDataHora] = useState("");
  const [etapas, setEtapas] = useState([]);
  const [etapaSelecionada, setEtapaSelecionada] = useState(null);
  const [settingsVisible, setSettingsVisible] = useState(true);
  const translateX = useRef(new Animated.Value(0)).current;
  const [arrowRotation] = useState(new Animated.Value(0));

  const toggleSettings = () => {
    setSettingsVisible(!settingsVisible);
    Animated.timing(translateX, {
      toValue: settingsVisible ? -200 : 0, // Ajuste conforme necessário
      duration: 300, // Duração da animação
      useNativeDriver: false,
    }).start();
    Animated.timing(arrowRotation, {
      toValue: settingsVisible ? 180 : 0,
      duration: 20,
      useNativeDriver: true,
    }).start();
  };

  const adicionarEtapa = () => {
    // Adiciona a nova etapa ao estado
    if (etapaSelecionada !== null) {
      // Editar a etapa existente
      const etapasAtualizadas = etapas.map((etapa, index) => {
        if (index === etapaSelecionada) {
          return { titulo, descricao, dataHora };
        }
        return etapa;
      });

      setEtapas(etapasAtualizadas);
      setEtapaSelecionada(null);
    } else {
      // Adicionar nova etapa
      setEtapas([...etapas, { titulo, descricao, dataHora }]);
    }
    // Fecha a modal
    setModalVisible(false);
  };

  const excluirEtapa = () => {
    if (etapaSelecionada !== null) {
      // Remove a etapa selecionada da lista
      const etapasAtualizadas = etapas.filter(
        (etapa, index) => index !== etapaSelecionada
      );
      setEtapas(etapasAtualizadas);
      // Limpa a seleção de etapa
      setEtapaSelecionada(null);
    }
  };

  return (
    <ScrollView style={styles.ScrollView}>
      <View style={styles.container}>
        <View style={styles.main}>
          {/* Botão "Adicionar Etapa" */}
          {/* Lista de Etapas */}
          <FlatList
  data={etapas}
  keyExtractor={(item, index) => index.toString()}
  renderItem={({ item, index }) => (
    <View style={styles.mainEtapa}>
      <TouchableOpacity
        style={styles.btnEtapa}
        onPress={() => {
          setModalVisible(true);
          setEtapaSelecionada(index);
          setTitulo(item.titulo);
          setDescricao(item.descricao);
          setDataHora(item.dataHora);
        }}
      >
        <Icon_Clock
          name="clock"
          size={60}
          color={"#FFF"}
        ></Icon_Clock>
      </TouchableOpacity>
      <View style={styles.boxEtapa}>
        <Text>{`Título: ${item.titulo}`}</Text>
        <Text>
          --------------------------------------------------------------
        </Text>
        <Text>{`Descrição: ${item.descricao}`}</Text>
      </View>
    </View>
  )}
/>

        </View>

        {/* Modal para adicionar/editar Etapa */}
        <Modal
          style={styles.Modal}
          animationType="fade"
          transparent={true}
          visible={modalVisible}
          onRequestClose={() => {
            setEtapaSelecionada(null);
            setModalVisible(false);
          }}
        >
          <View style={styles.modalContainer}>
            <Text style={styles.titulo}>
              {etapaSelecionada !== null
                ? "Editar Etapa"
                : "Adicionar Nova Etapa"}
            </Text>
            <View style={styles.modalContent}>
              <TextInput
                style={styles.inputTitulo}
                value={titulo}
                onChangeText={(text) => setTitulo(text)}
                placeholder="Título"
                placeholderTextColor="grey"
                maxLength={40}
              />
              <TextInput
                style={styles.inputDescricao}
                value={descricao}
                onChangeText={(text) => setDescricao(text)}
                placeholder="Descrição"
                placeholderTextColor="grey"
                maxLength={71}
              />
            </View>
            <TouchableOpacity
              style={styles.btnSalvar}
              title="Adicionar"
              onPress={adicionarEtapa}
            >
              <Text style={styles.txt}>
                {etapaSelecionada !== null ? "Salvar" : "Adicionar"}
              </Text>
            </TouchableOpacity>
          </View>
        </Modal>
      </View>

      {/* Corpo da seta */}
      <Animated.View
        style={{ ...styles.containerSeta, transform: [{ translateX }] }}
      >
        <View style={styles.settings}>
          <TouchableOpacity
            id="seta"
            onPress={toggleSettings}
            style={{
              ...styles.btnSeta,
              transform: [
                {
                  rotate: arrowRotation.interpolate({
                    inputRange: [0, 180],
                    outputRange: ["0deg", "180deg"],
                  }),
                },
              ],
            }}
          >
            <Icon_ArrowLeft
              name="arrowleft"
              size={50}
              color={"#FFF"}
            ></Icon_ArrowLeft>
          </TouchableOpacity>

          <TouchableOpacity
            id="adicionar"
            style={styles.btnAdd}
            onPress={() => {
              setEtapaSelecionada(null);
              setModalVisible(true);
            }}
          >
            <Icon_Plus name="plus" size={55} color={"#FFF"}></Icon_Plus>
          </TouchableOpacity>
          <TouchableOpacity
            id="editar"
            style={styles.btnEdit}
            onPress={() => {
              if (etapaSelecionada !== null) {
                setModalVisible(true);
              } else {
                // Se nenhum item foi selecionado, você pode exibir uma mensagem ou fazer outra coisa
                console.warn("Por favor, selecione uma etapa para editar.");
              }
            }}
          >
            <Icon_Edit name="pencil" size={40} color={"#FFF"}></Icon_Edit>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.btnDelete}
            onPress={() => {
              // Ao clicar no botão de excluir, define a etapa a ser excluída
              setEtapaSelecionada(index);
              // Chama a função para excluir a etapa
              excluirEtapa();
            }}
          >
            <Icon_Trash name="trash" size={35} color={"#FFF"}></Icon_Trash>
          </TouchableOpacity>
        </View>
      </Animated.View>
    </ScrollView>
  );
}
