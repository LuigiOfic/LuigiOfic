import { createNativeStackNavigator } from "@react-navigation/native-stack"
import Home from '../pages/Home';
import LoginScreen from '../pages/Login';
import Register from '../pages/Register';
import TimeLineScreen from "../pages/TimeLine";


const Stack =  createNativeStackNavigator();

export default  function Routes(){
    return (

        <Stack.Navigator>
             <Stack.Screen 
                name="Home"
                component={Home}
                options={{headerShown: false}}
            />
            <Stack.Screen 
                name="Login"
                component={LoginScreen}
                options={{headerShown: false}}
            />
            <Stack.Screen 
                name="Register"
                component={Register}
                options={{headerShown: false}}
            />
            <Stack.Screen
                name="TimeLine"
                component={TimeLineScreen}
                options={{headerShown: false}}
            />
        </Stack.Navigator>
    )
}